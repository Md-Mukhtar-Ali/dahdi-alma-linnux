#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xc1514a3b, "free_irq" },
	{ 0xa78af5f3, "ioread32" },
	{ 0xa27e3480, "pci_enable_device" },
	{ 0xb6ccfff4, "dahdi_hdlc_putbuf" },
	{ 0x4a453f53, "iowrite32" },
	{ 0xe5434453, "pci_iomap" },
	{ 0x96cfd392, "_dahdi_ec_span" },
	{ 0x3c4c1cb3, "dahdi_alarm_notify" },
	{ 0x842c8e9d, "ioread16" },
	{ 0x3fa69fab, "__pci_register_driver" },
	{ 0x6128b5fc, "__printk_ratelimit" },
	{ 0x8e3d8bc7, "dahdi_hdlc_getbuf" },
	{ 0xb164d90f, "pci_request_regions" },
	{ 0x37a0cba, "kfree" },
	{ 0x6a86bc1, "iowrite16" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x2abf2068, "__dynamic_dev_dbg" },
	{ 0x30b70f90, "pci_unregister_driver" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x92997ed8, "_printk" },
	{ 0x848d372e, "iowrite8" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x5df8475c, "_dev_info" },
	{ 0xe9b2fcf9, "device_create_file" },
	{ 0xea3c74e, "tasklet_kill" },
	{ 0x7fda9f1b, "_dahdi_receive" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0x19c2320b, "_dev_err" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0x3343baab, "dahdi_create_device" },
	{ 0x2364c85a, "tasklet_init" },
	{ 0xaafdc258, "strcasecmp" },
	{ 0x9ed12e20, "kmalloc_large" },
	{ 0xe55c96c8, "dahdi_unregister_device" },
	{ 0x20ac5ea8, "dahdi_register_device" },
	{ 0xe049cd34, "dahdi_hdlc_abort" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x5dc4dc3b, "pci_iounmap" },
	{ 0xb19b445, "ioread8" },
	{ 0x580d3873, "_dev_warn" },
	{ 0xf9c0b663, "strlcat" },
	{ 0x97c3c9cf, "param_ops_charp" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xfb384d37, "kasprintf" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x3f4c8c17, "_dev_notice" },
	{ 0xb4eb9cc0, "pci_release_regions" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x21cdee64, "dahdi_hdlc_finish" },
	{ 0x74cefc7c, "pci_disable_device" },
	{ 0xde0912ee, "kmalloc_trace" },
	{ 0xad4f5fde, "param_ops_int" },
	{ 0x94571e3b, "dahdi_free_device" },
	{ 0x2eb69d30, "kmalloc_caches" },
	{ 0x736c1b75, "_dahdi_transmit" },
	{ 0x91eb0f3a, "device_remove_file" },
	{ 0x4f5671f6, "module_layout" },
};

MODULE_INFO(depends, "dahdi");

MODULE_ALIAS("pci:v0000D161d0000B410sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00008014sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00008015sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00008016sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00008017sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "13969429517B456F50F6C76");
MODULE_INFO(rhelversion, "9.6");
