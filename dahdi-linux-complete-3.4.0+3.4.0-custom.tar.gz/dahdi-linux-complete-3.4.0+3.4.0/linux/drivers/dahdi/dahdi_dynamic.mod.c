#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

KSYMTAB_FUNC(dahdi_dynamic_receive, "", "");
KSYMTAB_FUNC(dahdi_dynamic_register_driver, "", "");
KSYMTAB_FUNC(dahdi_dynamic_unregister_driver, "", "");

SYMBOL_CRC(dahdi_dynamic_receive, 0xf6695e7c, "");
SYMBOL_CRC(dahdi_dynamic_register_driver, 0xd7454c0a, "");
SYMBOL_CRC(dahdi_dynamic_unregister_driver, 0x521cc812, "");

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x2364c85a, "tasklet_init" },
	{ 0x62a0511c, "dahdi_set_dynamic_ops" },
	{ 0x350f6ce5, "tasklet_unlock_wait" },
	{ 0xea3c74e, "tasklet_kill" },
	{ 0xb3087f55, "timer_delete_sync" },
	{ 0x9f15f501, "timer_delete" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x296695f, "refcount_warn_saturate" },
	{ 0x736c1b75, "_dahdi_transmit" },
	{ 0x3e3bad0a, "__tasklet_hi_schedule" },
	{ 0x7cb5bd4a, "dahdi_rbsbits" },
	{ 0x96cfd392, "_dahdi_ec_span" },
	{ 0x7fda9f1b, "_dahdi_receive" },
	{ 0xf706b8ea, "try_module_get" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xe740ace7, "module_put" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0xe55c96c8, "dahdi_unregister_device" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0x6091797f, "synchronize_rcu" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x2eb69d30, "kmalloc_caches" },
	{ 0xde0912ee, "kmalloc_trace" },
	{ 0x3343baab, "dahdi_create_device" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0xa916b694, "strnlen" },
	{ 0x476b165a, "sized_strscpy" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xf758c439, "dev_set_name" },
	{ 0x20ac5ea8, "dahdi_register_device" },
	{ 0xa24f23d8, "__request_module" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xad4f5fde, "param_ops_int" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x8d522714, "__rcu_read_lock" },
	{ 0x2469810f, "__rcu_read_unlock" },
	{ 0x92997ed8, "_printk" },
	{ 0x37a0cba, "kfree" },
	{ 0x94571e3b, "dahdi_free_device" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x3c4c1cb3, "dahdi_alarm_notify" },
	{ 0x3cf85989, "mod_timer" },
	{ 0x78534f62, "init_timer_key" },
	{ 0x4f5671f6, "module_layout" },
};

MODULE_INFO(depends, "dahdi");


MODULE_INFO(srcversion, "B0AD46332872694251533ED");
MODULE_INFO(rhelversion, "9.6");
