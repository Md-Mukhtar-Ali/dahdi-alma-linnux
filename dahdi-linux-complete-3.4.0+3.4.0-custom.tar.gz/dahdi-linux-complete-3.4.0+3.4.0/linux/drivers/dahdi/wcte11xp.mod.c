#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xa27e3480, "pci_enable_device" },
	{ 0x2eb69d30, "kmalloc_caches" },
	{ 0xde0912ee, "kmalloc_trace" },
	{ 0xf18416d1, "dma_alloc_attrs" },
	{ 0x4e373669, "pci_set_master" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0x333585b5, "pcpu_hot" },
	{ 0x8ddd8aad, "schedule_timeout" },
	{ 0x3c4c1cb3, "dahdi_alarm_notify" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0x736c1b75, "_dahdi_transmit" },
	{ 0xad4f5fde, "param_ops_int" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x3fa69fab, "__pci_register_driver" },
	{ 0xe55c96c8, "dahdi_unregister_device" },
	{ 0x37a0cba, "kfree" },
	{ 0x94571e3b, "dahdi_free_device" },
	{ 0x92997ed8, "_printk" },
	{ 0x30b70f90, "pci_unregister_driver" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x7cb5bd4a, "dahdi_rbsbits" },
	{ 0x2b8e4d1b, "__dahdi_ec_chunk" },
	{ 0x7fda9f1b, "_dahdi_receive" },
	{ 0x41474b91, "dma_free_attrs" },
	{ 0xc1514a3b, "free_irq" },
	{ 0x3343baab, "dahdi_create_device" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xfb384d37, "kasprintf" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0x20ac5ea8, "dahdi_register_device" },
	{ 0x4f5671f6, "module_layout" },
};

MODULE_INFO(depends, "dahdi");

MODULE_ALIAS("pci:v0000E159d00000001sv000071FEsd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv000079FEsd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv0000795Esd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv000079DEsd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv0000797Esd*bc*sc*i*");

MODULE_INFO(srcversion, "27F8F6180B2BF4DFFC5A559");
MODULE_INFO(rhelversion, "9.6");
