#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x9465d0d3, "single_open" },
	{ 0x8d522714, "__rcu_read_lock" },
	{ 0x8f4a4328, "seq_printf" },
	{ 0x2469810f, "__rcu_read_unlock" },
	{ 0x1dd18d5, "__dev_queue_xmit" },
	{ 0x1c40e10c, "skb_dequeue" },
	{ 0xb3087f55, "timer_delete_sync" },
	{ 0x2b03bd6e, "dev_remove_pack" },
	{ 0x9d0d6206, "unregister_netdevice_notifier" },
	{ 0x521cc812, "dahdi_dynamic_unregister_driver" },
	{ 0x6f20cbb9, "remove_proc_entry" },
	{ 0x2eb69d30, "kmalloc_caches" },
	{ 0xde0912ee, "kmalloc_trace" },
	{ 0xa916b694, "strnlen" },
	{ 0x476b165a, "sized_strscpy" },
	{ 0xbcab6ee6, "sscanf" },
	{ 0x53732483, "init_net" },
	{ 0xf891f0ae, "dev_get_by_name" },
	{ 0x69dd3b5b, "crc32_le" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0x37a0cba, "kfree" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x6091797f, "synchronize_rcu" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x352a72b0, "skb_pull" },
	{ 0xf6695e7c, "dahdi_dynamic_receive" },
	{ 0x9ac16cb0, "sk_skb_reason_drop" },
	{ 0xb50f07ad, "__pskb_pull_tail" },
	{ 0x69acdf38, "memcpy" },
	{ 0xb3c5a548, "__netdev_alloc_skb" },
	{ 0x48d51864, "skb_put" },
	{ 0xfb578fc5, "memset" },
	{ 0xc1287f38, "skb_push" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x3dab84b5, "skb_queue_tail" },
	{ 0xfca332f, "seq_read" },
	{ 0xb3b01031, "seq_lseek" },
	{ 0x19bd6d9f, "seq_release" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x78534f62, "init_timer_key" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x3cf85989, "mod_timer" },
	{ 0x16e7f07d, "dev_add_pack" },
	{ 0xd2da1048, "register_netdevice_notifier" },
	{ 0xd7454c0a, "dahdi_dynamic_register_driver" },
	{ 0x8cb52089, "proc_create_data" },
	{ 0x92997ed8, "_printk" },
	{ 0x4f5671f6, "module_layout" },
};

MODULE_INFO(depends, "dahdi_dynamic");


MODULE_INFO(srcversion, "22CC1C9C37C1393E37570DE");
MODULE_INFO(rhelversion, "9.6");
