#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x1c40e10c, "skb_dequeue" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x92997ed8, "_printk" },
	{ 0x37a0cba, "kfree" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x521cc812, "dahdi_dynamic_unregister_driver" },
	{ 0x9d0d6206, "unregister_netdevice_notifier" },
	{ 0x2b03bd6e, "dev_remove_pack" },
	{ 0x43d4550, "skb_queue_purge_reason" },
	{ 0xb3c5a548, "__netdev_alloc_skb" },
	{ 0x48d51864, "skb_put" },
	{ 0x69acdf38, "memcpy" },
	{ 0xc1287f38, "skb_push" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x3dab84b5, "skb_queue_tail" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x352a72b0, "skb_pull" },
	{ 0xf6695e7c, "dahdi_dynamic_receive" },
	{ 0x9ac16cb0, "sk_skb_reason_drop" },
	{ 0xb50f07ad, "__pskb_pull_tail" },
	{ 0x754d539c, "strlen" },
	{ 0x2eb69d30, "kmalloc_caches" },
	{ 0xde0912ee, "kmalloc_trace" },
	{ 0xa916b694, "strnlen" },
	{ 0x476b165a, "sized_strscpy" },
	{ 0x349cba85, "strchr" },
	{ 0x53732483, "init_net" },
	{ 0xf891f0ae, "dev_get_by_name" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x16e7f07d, "dev_add_pack" },
	{ 0xd2da1048, "register_netdevice_notifier" },
	{ 0xd7454c0a, "dahdi_dynamic_register_driver" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x1dd18d5, "__dev_queue_xmit" },
	{ 0x4f5671f6, "module_layout" },
};

MODULE_INFO(depends, "dahdi_dynamic");


MODULE_INFO(srcversion, "24D22E1D41021D76F6936B8");
MODULE_INFO(rhelversion, "9.6");
