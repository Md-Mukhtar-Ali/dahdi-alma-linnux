#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x39223b0, "pci_save_state" },
	{ 0xc1514a3b, "free_irq" },
	{ 0xc6d09aa9, "release_firmware" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0xa27e3480, "pci_enable_device" },
	{ 0xb6ccfff4, "dahdi_hdlc_putbuf" },
	{ 0x7f02188f, "__msecs_to_jiffies" },
	{ 0xe5434453, "pci_iomap" },
	{ 0xc1198662, "__warn_flushing_systemwide_wq" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x96cfd392, "_dahdi_ec_span" },
	{ 0x3c4c1cb3, "dahdi_alarm_notify" },
	{ 0xa94cff0e, "request_firmware" },
	{ 0x3fa69fab, "__pci_register_driver" },
	{ 0x2c20e37d, "Oct6100ApiGetCapacityPinsDef" },
	{ 0x6128b5fc, "__printk_ratelimit" },
	{ 0x8e3d8bc7, "dahdi_hdlc_getbuf" },
	{ 0x238df932, "Oct6100EventGetTone" },
	{ 0xb164d90f, "pci_request_regions" },
	{ 0x37a0cba, "kfree" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x2abf2068, "__dynamic_dev_dbg" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0xa498779d, "Oct6100ChannelModify" },
	{ 0x30b70f90, "pci_unregister_driver" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x92997ed8, "_printk" },
	{ 0x73382716, "Oct6100EventGetToneDef" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x5df8475c, "_dev_info" },
	{ 0xe9b2fcf9, "device_create_file" },
	{ 0x9404793, "Oct6100ToneDetectionEnable" },
	{ 0x7fda9f1b, "_dahdi_receive" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0x19c2320b, "_dev_err" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0xc054a762, "Oct6100ApiGetCapacityPins" },
	{ 0x3343baab, "dahdi_create_device" },
	{ 0x79be733f, "dahdi_qevent_lock" },
	{ 0x69dd3b5b, "crc32_le" },
	{ 0x3fde93a5, "Oct6100InterruptServiceRoutineDef" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0xf18416d1, "dma_alloc_attrs" },
	{ 0x2d4d420f, "Oct6100ChipOpenDef" },
	{ 0x8bcefb0d, "Oct6100GetInstanceSizeDef" },
	{ 0x33729020, "Oct6100InterruptServiceRoutine" },
	{ 0xaafdc258, "strcasecmp" },
	{ 0xa5f12cec, "dahdi_init_span" },
	{ 0xe55c96c8, "dahdi_unregister_device" },
	{ 0x4c29be43, "dahdi_spantype2str" },
	{ 0x20ac5ea8, "dahdi_register_device" },
	{ 0xe049cd34, "dahdi_hdlc_abort" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x5dc4dc3b, "pci_iounmap" },
	{ 0x297b903b, "pci_restore_state" },
	{ 0xfb578fc5, "memset" },
	{ 0x580d3873, "_dev_warn" },
	{ 0x8887613e, "Oct6100ChannelModifyDef" },
	{ 0x4e373669, "pci_set_master" },
	{ 0x97c3c9cf, "param_ops_charp" },
	{ 0x9166fc03, "__flush_workqueue" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0xfb384d37, "kasprintf" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x7f3521aa, "Oct6100GetInstanceSize" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x3f4c8c17, "_dev_notice" },
	{ 0x41474b91, "dma_free_attrs" },
	{ 0x999e8297, "vfree" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x2b8e4d1b, "__dahdi_ec_chunk" },
	{ 0xb4eb9cc0, "pci_release_regions" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x6eefa3a6, "Oct6100ChipCloseDef" },
	{ 0x6729d3df, "__get_user_4" },
	{ 0x21cdee64, "dahdi_hdlc_finish" },
	{ 0xe59837f0, "Oct6100ChipClose" },
	{ 0x20728ec0, "Oct6100ChannelOpenDef" },
	{ 0xc07351b3, "__SCT__cond_resched" },
	{ 0xde0912ee, "kmalloc_trace" },
	{ 0xad4f5fde, "param_ops_int" },
	{ 0xd6ee688f, "vmalloc" },
	{ 0x94571e3b, "dahdi_free_device" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0xef4b16bf, "Oct6100ChipOpen" },
	{ 0x7cb5bd4a, "dahdi_rbsbits" },
	{ 0xf9a482f9, "msleep" },
	{ 0x2eb69d30, "kmalloc_caches" },
	{ 0x736c1b75, "_dahdi_transmit" },
	{ 0x91eb0f3a, "device_remove_file" },
	{ 0x6ea97ba9, "Oct6100ToneDetectionEnableDef" },
	{ 0x2d3385d3, "system_wq" },
	{ 0xf8a56864, "Oct6100ChannelOpen" },
	{ 0x4f5671f6, "module_layout" },
};

MODULE_INFO(depends, "dahdi,oct612x");

MODULE_ALIAS("pci:v000010EEd00000314sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00001820sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00001420sv00000005sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00001410sv00000005sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00001405sv00000005sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000420sv00000004sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000410sv00000004sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000405sv00000004sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000410sv00000003sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000405sv00000003sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000410sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000405sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00001220sv00000005sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00001205sv00000005sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00001210sv00000005sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000220sv00000004sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000205sv00000004sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000210sv00000004sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000205sv00000003sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000210sv00000003sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000205sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000210sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "8313C2E2C5C3A63B02B3C60");
MODULE_INFO(rhelversion, "9.6");
