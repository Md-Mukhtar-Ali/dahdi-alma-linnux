#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xcaca3dcb, "xframe_next_packet" },
	{ 0xf2b2d6d8, "xpd_driver_unregister" },
	{ 0x7f0b8305, "param_ops_uint" },
	{ 0x88173772, "xpp_register_request" },
	{ 0x656e4a6e, "snprintf" },
	{ 0x2763e0d7, "xpd_set_spanname" },
	{ 0x3c4c1cb3, "dahdi_alarm_notify" },
	{ 0x64a6fdeb, "alarm2str" },
	{ 0xaa1f4c6a, "xpd_alloc" },
	{ 0xb2cc48ff, "elect_syncer" },
	{ 0x9de213a9, "dahdi_sync_tick" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x92997ed8, "_printk" },
	{ 0x96b29254, "strncasecmp" },
	{ 0xda36bc09, "xpp_close" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xdf4a66f5, "update_wanted_pcm_mask" },
	{ 0xe9b2fcf9, "device_create_file" },
	{ 0x2ef28734, "pcmtx" },
	{ 0x6516419d, "xproto_register" },
	{ 0x81e85d4c, "xproto_card_entry" },
	{ 0xf1bc084, "mark_offhook" },
	{ 0xebdc04c8, "xpp_echocan_create" },
	{ 0xa5f12cec, "dahdi_init_span" },
	{ 0x4c29be43, "dahdi_spantype2str" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x67c3bd86, "phonedev_alloc_channels" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xc9b187a7, "xpp_open" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x1ac5d3cb, "strcspn" },
	{ 0xebd9f0ac, "notify_bad_xpd" },
	{ 0xa86a9467, "xpp_ioctl" },
	{ 0x37ae751e, "xpp_echocan_name" },
	{ 0xcb5d966a, "get_xframe" },
	{ 0xb027c2e6, "xpd_byaddr" },
	{ 0xf79363a0, "report_bad_ioctl" },
	{ 0x97438c62, "dump_packet" },
	{ 0x4bacc879, "xpp_maint" },
	{ 0xc3b63d8, "pcmtx_chan" },
	{ 0xd8b88774, "xpp_span_assigned" },
	{ 0x30bb292a, "send_cmd_frame" },
	{ 0xad4f5fde, "param_ops_int" },
	{ 0x349cba85, "strchr" },
	{ 0x40448091, "xproto_unregister" },
	{ 0xffba2f0e, "xpd_driver_register" },
	{ 0x7cb5bd4a, "dahdi_rbsbits" },
	{ 0xf9a482f9, "msleep" },
	{ 0x91eb0f3a, "device_remove_file" },
	{ 0x4f5671f6, "module_layout" },
};

MODULE_INFO(depends, "xpp,dahdi");


MODULE_INFO(srcversion, "0EEF360573A6DEEEE1F27EB");
MODULE_INFO(rhelversion, "9.6");
