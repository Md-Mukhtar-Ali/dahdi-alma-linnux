#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x8f4a4328, "seq_printf" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x72fb3fbd, "usb_free_coherent" },
	{ 0x3bd49137, "kmem_cache_free" },
	{ 0xb3e67bb, "kmem_cache_alloc" },
	{ 0x94037858, "usb_init_urb" },
	{ 0x1151342, "usb_alloc_coherent" },
	{ 0xb591241f, "xframe_init" },
	{ 0xb43f9365, "ktime_get" },
	{ 0x1d65b52a, "usb_submit_urb" },
	{ 0xb9f3acd8, "put_xframe" },
	{ 0xb86aba72, "dump_xframe" },
	{ 0x45b5b4fc, "kmem_cache_destroy" },
	{ 0xfac9e980, "kmem_cache_create" },
	{ 0xfc68c744, "usb_register_driver" },
	{ 0xecc1e7d6, "usb_deregister" },
	{ 0xcb5d966a, "get_xframe" },
	{ 0xd2f23094, "xbus_receive_xframe" },
	{ 0x4752d2f9, "usb_reset_device" },
	{ 0x2eb69d30, "kmalloc_caches" },
	{ 0xde0912ee, "kmalloc_trace" },
	{ 0xb10f252b, "usb_register_dev" },
	{ 0x858887cd, "xbus_new" },
	{ 0x656e4a6e, "snprintf" },
	{ 0x8cb52089, "proc_create_data" },
	{ 0xef000341, "xbus_connect" },
	{ 0xfca332f, "seq_read" },
	{ 0xb3b01031, "seq_lseek" },
	{ 0x1d485f22, "single_release" },
	{ 0x7f0b8305, "param_ops_uint" },
	{ 0xad4f5fde, "param_ops_int" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x92997ed8, "_printk" },
	{ 0x114ee7a1, "usb_altnum_to_altsetting" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0xd0570e13, "xbus_num" },
	{ 0x6f20cbb9, "remove_proc_entry" },
	{ 0x63a82858, "xbus_disconnect" },
	{ 0x6626afca, "down" },
	{ 0xd71c094a, "usb_deregister_dev" },
	{ 0xcf2a6966, "up" },
	{ 0x37a0cba, "kfree" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x9465d0d3, "single_open" },
	{ 0x4f5671f6, "module_layout" },
};

MODULE_INFO(depends, "xpp");

MODULE_ALIAS("usb:vE4E4p1132d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:vE4E4p1142d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:vE4E4p1152d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:vE4E4p1162d*dc*dsc*dp*ic*isc*ip*in*");

MODULE_INFO(srcversion, "6E1A57B6B21E84E97FE3696");
MODULE_INFO(rhelversion, "9.6");
