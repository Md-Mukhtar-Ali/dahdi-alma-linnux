#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xf2b2d6d8, "xpd_driver_unregister" },
	{ 0x7f0b8305, "param_ops_uint" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x88173772, "xpp_register_request" },
	{ 0x656e4a6e, "snprintf" },
	{ 0x201083ac, "hookstate_changed" },
	{ 0x2303f47e, "generic_echocancel_setmask" },
	{ 0xaa1f4c6a, "xpd_alloc" },
	{ 0xb3b01031, "seq_lseek" },
	{ 0xf1e8866a, "generic_timing_priority" },
	{ 0x8cb52089, "proc_create_data" },
	{ 0x17e73588, "generic_echocancel_timeslot" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x3c7f5652, "generic_card_pcm_tospan" },
	{ 0xc36b1105, "generic_card_pcm_fromspan" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x92997ed8, "_printk" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xe4ffbbde, "xpd_free" },
	{ 0xe9b2fcf9, "device_create_file" },
	{ 0x79be733f, "dahdi_qevent_lock" },
	{ 0x6516419d, "xproto_register" },
	{ 0x81e85d4c, "xproto_card_entry" },
	{ 0xaafdc258, "strcasecmp" },
	{ 0xbcab6ee6, "sscanf" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x1e1e140e, "ns_to_timespec64" },
	{ 0x2f5bfcec, "oht_pcm" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xfca332f, "seq_read" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0xb796525, "param_ops_bool" },
	{ 0x6729d3df, "__get_user_4" },
	{ 0x6f20cbb9, "remove_proc_entry" },
	{ 0xb43f9365, "ktime_get" },
	{ 0x8f4a4328, "seq_printf" },
	{ 0xf79363a0, "report_bad_ioctl" },
	{ 0x1d485f22, "single_release" },
	{ 0x10af23d5, "xpp_ram_request" },
	{ 0x1accab49, "generic_card_pcm_recompute" },
	{ 0xda5d2b7d, "notify_rxsig" },
	{ 0xad4f5fde, "param_ops_int" },
	{ 0x9465d0d3, "single_open" },
	{ 0x40448091, "xproto_unregister" },
	{ 0xffba2f0e, "xpd_driver_register" },
	{ 0xf9a482f9, "msleep" },
	{ 0x91eb0f3a, "device_remove_file" },
	{ 0x4f5671f6, "module_layout" },
};

MODULE_INFO(depends, "xpp,dahdi");


MODULE_INFO(srcversion, "E80CBAD39FFDBDB7D8C0DD8");
MODULE_INFO(rhelversion, "9.6");
