#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xcaca3dcb, "xframe_next_packet" },
	{ 0xf2b2d6d8, "xpd_driver_unregister" },
	{ 0xaa1f4c6a, "xpd_alloc" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x92997ed8, "_printk" },
	{ 0x6516419d, "xproto_register" },
	{ 0x81e85d4c, "xproto_card_entry" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xebd9f0ac, "notify_bad_xpd" },
	{ 0xcb5d966a, "get_xframe" },
	{ 0xb027c2e6, "xpd_byaddr" },
	{ 0x30bb292a, "send_cmd_frame" },
	{ 0xad4f5fde, "param_ops_int" },
	{ 0x40448091, "xproto_unregister" },
	{ 0xffba2f0e, "xpd_driver_register" },
	{ 0x4f5671f6, "module_layout" },
};

MODULE_INFO(depends, "xpp");


MODULE_INFO(srcversion, "1E931F16E0AC37F7F4D5C04");
MODULE_INFO(rhelversion, "9.6");
