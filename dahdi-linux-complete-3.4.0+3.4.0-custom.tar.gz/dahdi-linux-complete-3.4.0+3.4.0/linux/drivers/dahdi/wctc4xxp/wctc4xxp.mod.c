#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xc1514a3b, "free_irq" },
	{ 0xc31db0ce, "is_vmalloc_addr" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0xc6d09aa9, "release_firmware" },
	{ 0xb079d434, "skb_copy_bits" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0xa27e3480, "pci_enable_device" },
	{ 0x48d51864, "skb_put" },
	{ 0xe5434453, "pci_iomap" },
	{ 0xfc318d89, "netif_napi_add_weight" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xa6257a2f, "complete" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x42bd3968, "unregister_netdev" },
	{ 0x1c40e10c, "skb_dequeue" },
	{ 0x92540fbf, "finish_wait" },
	{ 0xf22a5fbc, "dma_unmap_page_attrs" },
	{ 0xa94cff0e, "request_firmware" },
	{ 0x3fa69fab, "__pci_register_driver" },
	{ 0x6128b5fc, "__printk_ratelimit" },
	{ 0xea26da, "dahdi_transcoder_free" },
	{ 0x69acdf38, "memcpy" },
	{ 0x37a0cba, "kfree" },
	{ 0x333585b5, "pcpu_hot" },
	{ 0xbf129fee, "pci_clear_mwi" },
	{ 0x8c26d495, "prepare_to_wait_event" },
	{ 0xb3087f55, "timer_delete_sync" },
	{ 0xe2964344, "__wake_up" },
	{ 0xfac9e980, "kmem_cache_create" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0xe396e21, "ether_setup" },
	{ 0x30b70f90, "pci_unregister_driver" },
	{ 0x1035c7c2, "__release_region" },
	{ 0xdb3f81, "dahdi_transcoder_alloc" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xd6f69415, "dev_driver_string" },
	{ 0x1f1a825e, "eth_type_trans" },
	{ 0xe5ff2262, "dma_map_page_attrs" },
	{ 0xa91a4a18, "napi_complete_done" },
	{ 0xf15cb406, "alloc_netdev_mqs" },
	{ 0x8ddd8aad, "schedule_timeout" },
	{ 0x1000e51, "schedule" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xf915ffd4, "__napi_schedule" },
	{ 0x19820b0d, "__alloc_skb" },
	{ 0xb3e67bb, "kmem_cache_alloc" },
	{ 0x5df8475c, "_dev_info" },
	{ 0x3dab84b5, "skb_queue_tail" },
	{ 0x47f0fad3, "dahdi_transcoder_alert" },
	{ 0x7cd8d75e, "page_offset_base" },
	{ 0xda2b461f, "pci_set_mwi" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0x19c2320b, "_dev_err" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0x9ac16cb0, "sk_skb_reason_drop" },
	{ 0x3cf85989, "mod_timer" },
	{ 0x3bd49137, "kmem_cache_free" },
	{ 0xf18416d1, "dma_alloc_attrs" },
	{ 0x93309d8a, "napi_enable" },
	{ 0x30f409be, "netif_receive_skb" },
	{ 0x8cc03c2e, "register_netdev" },
	{ 0xffd5637f, "free_netdev" },
	{ 0x4c9d28b0, "phys_base" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0xfef216eb, "_raw_spin_trylock" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0xaa6583cc, "dahdi_transcoder_register" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x5dc4dc3b, "pci_iounmap" },
	{ 0xfb578fc5, "memset" },
	{ 0x580d3873, "_dev_warn" },
	{ 0x4e373669, "pci_set_master" },
	{ 0x97c3c9cf, "param_ops_charp" },
	{ 0x25974000, "wait_for_completion" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0x6d16c104, "mutex_lock_killable" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x97651e6c, "vmemmap_base" },
	{ 0x41474b91, "dma_free_attrs" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x78534f62, "init_timer_key" },
	{ 0x56470118, "__warn_printk" },
	{ 0x81bb7d7b, "dma_set_mask" },
	{ 0xde0912ee, "kmalloc_trace" },
	{ 0x2d5a8652, "napi_schedule_prep" },
	{ 0x5e6d4a, "pci_read_config_byte" },
	{ 0x754d539c, "strlen" },
	{ 0x3c8e586a, "napi_disable" },
	{ 0x77358855, "iomem_resource" },
	{ 0xdeaddae9, "dev_kfree_skb_any_reason" },
	{ 0xe486bef4, "dahdi_transcoder_unregister" },
	{ 0xad4f5fde, "param_ops_int" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0xf9a482f9, "msleep" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0xe2c17b5d, "__SCT__might_resched" },
	{ 0x2eb69d30, "kmalloc_caches" },
	{ 0x85bd1608, "__request_region" },
	{ 0x45b5b4fc, "kmem_cache_destroy" },
	{ 0x2d3385d3, "system_wq" },
	{ 0x4f5671f6, "module_layout" },
};

MODULE_INFO(depends, "dahdi_transcode");

MODULE_ALIAS("pci:v0000D161d00003400sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00008004sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "787C3DC6812105CDC6E26D2");
MODULE_INFO(rhelversion, "9.6");
