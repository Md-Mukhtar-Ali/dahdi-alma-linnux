#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

KSYMTAB_FUNC(voicebus_set_minlatency, "", "");
KSYMTAB_FUNC(voicebus_current_latency, "", "");
KSYMTAB_FUNC(voicebus_transmit, "", "");
KSYMTAB_FUNC(voicebus_start, "", "");
KSYMTAB_FUNC(voicebus_stop, "", "");
KSYMTAB_FUNC(voicebus_quiesce, "", "");
KSYMTAB_FUNC(voicebus_release, "", "");
KSYMTAB_FUNC(__voicebus_init, "", "");
KSYMTAB_FUNC(vpmadtreg_register, "", "");
KSYMTAB_FUNC(vpmadtreg_unregister, "", "");
KSYMTAB_FUNC(vpmadt032_echocan_create, "", "");
KSYMTAB_FUNC(vpmadt032_echocan_free, "", "");
KSYMTAB_FUNC(vpmadt032_alloc, "", "");
KSYMTAB_FUNC(vpmadt032_reset, "", "");
KSYMTAB_FUNC(vpmadt032_test, "", "");
KSYMTAB_FUNC(vpmadt032_init, "", "");
KSYMTAB_FUNC(vpmadt032_get_default_parameters, "", "");
KSYMTAB_FUNC(vpmadt032_free, "", "");
KSYMTAB_FUNC(gpakConfigurePorts, "", "");
KSYMTAB_FUNC(gpakConfigureChannel, "", "");
KSYMTAB_FUNC(gpakAlgControl, "", "");
KSYMTAB_FUNC(gpakPingDsp, "", "");
KSYMTAB_FUNC(vpmoct_alloc, "", "");
KSYMTAB_FUNC(vpmoct_free, "", "");
KSYMTAB_FUNC(vpmoct_init, "", "");
KSYMTAB_FUNC(vpmoct_echocan_create, "", "");
KSYMTAB_FUNC(vpmoct_echocan_free, "", "");
KSYMTAB_FUNC(vpmoct_preecho_enable, "", "");
KSYMTAB_FUNC(vpmoct_preecho_disable, "", "");

SYMBOL_CRC(voicebus_set_minlatency, 0xb92a3110, "");
SYMBOL_CRC(voicebus_current_latency, 0x8a88e027, "");
SYMBOL_CRC(voicebus_transmit, 0xc613fbb2, "");
SYMBOL_CRC(voicebus_start, 0x8949035d, "");
SYMBOL_CRC(voicebus_stop, 0xefd557c8, "");
SYMBOL_CRC(voicebus_quiesce, 0x00052c4e, "");
SYMBOL_CRC(voicebus_release, 0x07dbce3a, "");
SYMBOL_CRC(__voicebus_init, 0x7cc768eb, "");
SYMBOL_CRC(vpmadtreg_register, 0x36da2034, "");
SYMBOL_CRC(vpmadtreg_unregister, 0xbce42ec6, "");
SYMBOL_CRC(vpmadt032_echocan_create, 0x0e704620, "");
SYMBOL_CRC(vpmadt032_echocan_free, 0x2d10ec89, "");
SYMBOL_CRC(vpmadt032_alloc, 0x84e5d12b, "");
SYMBOL_CRC(vpmadt032_reset, 0x424f58b5, "");
SYMBOL_CRC(vpmadt032_test, 0x3cca6414, "");
SYMBOL_CRC(vpmadt032_init, 0x02dc23c1, "");
SYMBOL_CRC(vpmadt032_get_default_parameters, 0x102cf10b, "");
SYMBOL_CRC(vpmadt032_free, 0x48070f9c, "");
SYMBOL_CRC(gpakConfigurePorts, 0x635a1d83, "");
SYMBOL_CRC(gpakConfigureChannel, 0xe8a9b8fa, "");
SYMBOL_CRC(gpakAlgControl, 0x8019389a, "");
SYMBOL_CRC(gpakPingDsp, 0xe5eb1132, "");
SYMBOL_CRC(vpmoct_alloc, 0xfc33700b, "");
SYMBOL_CRC(vpmoct_free, 0x28ff10ba, "");
SYMBOL_CRC(vpmoct_init, 0x2457c9c4, "");
SYMBOL_CRC(vpmoct_echocan_create, 0x47624369, "");
SYMBOL_CRC(vpmoct_echocan_free, 0x5424fec5, "");
SYMBOL_CRC(vpmoct_preecho_enable, 0xd3d6a631, "");
SYMBOL_CRC(vpmoct_preecho_disable, 0xd87087de, "");

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xc1514a3b, "free_irq" },
	{ 0xf706b8ea, "try_module_get" },
	{ 0xc6d09aa9, "release_firmware" },
	{ 0xdf9208c0, "alloc_workqueue" },
	{ 0x1f3c8e7d, "dma_pool_create" },
	{ 0x4a3ad70e, "wait_for_completion_timeout" },
	{ 0xa27e3480, "pci_enable_device" },
	{ 0xe5434453, "pci_iomap" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x608741b5, "__init_swait_queue_head" },
	{ 0xa94cff0e, "request_firmware" },
	{ 0xcf2a6966, "up" },
	{ 0x6128b5fc, "__printk_ratelimit" },
	{ 0x37a0cba, "kfree" },
	{ 0xfcec0987, "enable_irq" },
	{ 0x333585b5, "pcpu_hot" },
	{ 0xbf129fee, "pci_clear_mwi" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x2abf2068, "__dynamic_dev_dbg" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0x1035c7c2, "__release_region" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x678b96ec, "dma_pool_alloc" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x92997ed8, "_printk" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x6383b27c, "__x86_indirect_thunk_rdx" },
	{ 0x5df8475c, "_dev_info" },
	{ 0xe740ace7, "module_put" },
	{ 0xda2b461f, "pci_set_mwi" },
	{ 0xea3c74e, "tasklet_kill" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0x19c2320b, "_dev_err" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0x2f7754a8, "dma_pool_free" },
	{ 0x2364c85a, "tasklet_init" },
	{ 0x6626afca, "down" },
	{ 0x8c03d20c, "destroy_workqueue" },
	{ 0x69dd3b5b, "crc32_le" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0xf18416d1, "dma_alloc_attrs" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0x20ac5ea8, "dahdi_register_device" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x5dc4dc3b, "pci_iounmap" },
	{ 0x11089ac7, "_ctype" },
	{ 0xfb578fc5, "memset" },
	{ 0x580d3873, "_dev_warn" },
	{ 0x4e373669, "pci_set_master" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x3f4c8c17, "_dev_notice" },
	{ 0xb5aa7165, "dma_pool_destroy" },
	{ 0x41474b91, "dma_free_attrs" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x3c12dfe, "cancel_work_sync" },
	{ 0x74cefc7c, "pci_disable_device" },
	{ 0x81bb7d7b, "dma_set_mask" },
	{ 0x362f9a8, "__x86_indirect_thunk_r12" },
	{ 0xde0912ee, "kmalloc_trace" },
	{ 0x5e6d4a, "pci_read_config_byte" },
	{ 0x77358855, "iomem_resource" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0xf9a482f9, "msleep" },
	{ 0xe2c17b5d, "__SCT__might_resched" },
	{ 0x2eb69d30, "kmalloc_caches" },
	{ 0x85bd1608, "__request_region" },
	{ 0xa24f23d8, "__request_module" },
	{ 0x2d3385d3, "system_wq" },
	{ 0x3ce4ca6f, "disable_irq" },
	{ 0x4f5671f6, "module_layout" },
};

MODULE_INFO(depends, "dahdi");


MODULE_INFO(srcversion, "F6CBA65D6C97D237059BF2B");
MODULE_INFO(rhelversion, "9.6");
