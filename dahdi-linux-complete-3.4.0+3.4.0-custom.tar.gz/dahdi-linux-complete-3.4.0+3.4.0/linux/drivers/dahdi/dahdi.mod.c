#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

KSYMTAB_DATA(dahdi_transcode_fops, "", "");
KSYMTAB_FUNC(dahdi_init_tone_state, "", "");
KSYMTAB_FUNC(dahdi_mf_tone, "", "");
KSYMTAB_DATA(__dahdi_mulaw, "", "");
KSYMTAB_DATA(__dahdi_alaw, "", "");
KSYMTAB_DATA(__dahdi_lin2mu, "", "");
KSYMTAB_DATA(__dahdi_lin2a, "", "");
KSYMTAB_FUNC(dahdi_rbsbits, "", "");
KSYMTAB_FUNC(dahdi_qevent_nolock, "", "");
KSYMTAB_FUNC(dahdi_qevent_lock, "", "");
KSYMTAB_FUNC(dahdi_hooksig, "", "");
KSYMTAB_FUNC(dahdi_alarm_notify, "", "");
KSYMTAB_FUNC(dahdi_hdlc_abort, "", "");
KSYMTAB_FUNC(dahdi_hdlc_finish, "", "");
KSYMTAB_FUNC(dahdi_hdlc_getbuf, "", "");
KSYMTAB_FUNC(dahdi_hdlc_putbuf, "", "");
KSYMTAB_FUNC(dahdi_alarm_channel, "", "");
KSYMTAB_FUNC(dahdi_register_echocan_factory, "", "");
KSYMTAB_FUNC(dahdi_unregister_echocan_factory, "", "");
KSYMTAB_FUNC(dahdi_set_hpec_ioctl, "", "");
KSYMTAB_FUNC(dahdi_str2spantype, "", "");
KSYMTAB_FUNC(dahdi_spantype2str, "", "");
KSYMTAB_FUNC(dahdi_lineconfig_bit_name, "", "");
KSYMTAB_FUNC(lineconfig_str, "", "");
KSYMTAB_FUNC(dahdi_lboname, "", "");
KSYMTAB_FUNC(dahdi_set_dynamic_ops, "", "");
KSYMTAB_FUNC(dahdi_create_device, "", "");
KSYMTAB_FUNC(dahdi_free_device, "", "");
KSYMTAB_FUNC(dahdi_init_span, "", "");
KSYMTAB_FUNC(dahdi_get_auto_assign_spans, "", "");
KSYMTAB_FUNC(dahdi_register_device, "", "");
KSYMTAB_FUNC(dahdi_unregister_device, "", "");
KSYMTAB_FUNC(__dahdi_ec_chunk, "", "");
KSYMTAB_FUNC(_dahdi_ec_span, "", "");
KSYMTAB_FUNC(_dahdi_transmit, "", "");
KSYMTAB_FUNC(_dahdi_receive, "", "");
KSYMTAB_FUNC(dahdi_register_chardev, "", "");
KSYMTAB_FUNC(dahdi_unregister_chardev, "", "");

SYMBOL_CRC(dahdi_transcode_fops, 0x15e800af, "");
SYMBOL_CRC(dahdi_init_tone_state, 0xf42f429a, "");
SYMBOL_CRC(dahdi_mf_tone, 0x9b443ea6, "");
SYMBOL_CRC(__dahdi_mulaw, 0x006a2198, "");
SYMBOL_CRC(__dahdi_alaw, 0xc4071a06, "");
SYMBOL_CRC(__dahdi_lin2mu, 0x0cca3f0e, "");
SYMBOL_CRC(__dahdi_lin2a, 0xb48548fa, "");
SYMBOL_CRC(dahdi_rbsbits, 0x7cb5bd4a, "");
SYMBOL_CRC(dahdi_qevent_nolock, 0xb8399d04, "");
SYMBOL_CRC(dahdi_qevent_lock, 0x79be733f, "");
SYMBOL_CRC(dahdi_hooksig, 0xa5bea5d9, "");
SYMBOL_CRC(dahdi_alarm_notify, 0x3c4c1cb3, "");
SYMBOL_CRC(dahdi_hdlc_abort, 0xe049cd34, "");
SYMBOL_CRC(dahdi_hdlc_finish, 0x21cdee64, "");
SYMBOL_CRC(dahdi_hdlc_getbuf, 0x8e3d8bc7, "");
SYMBOL_CRC(dahdi_hdlc_putbuf, 0xb6ccfff4, "");
SYMBOL_CRC(dahdi_alarm_channel, 0x96a79160, "");
SYMBOL_CRC(dahdi_register_echocan_factory, 0x93b3417c, "");
SYMBOL_CRC(dahdi_unregister_echocan_factory, 0x7ad1aafa, "");
SYMBOL_CRC(dahdi_set_hpec_ioctl, 0xe5a73e62, "");
SYMBOL_CRC(dahdi_str2spantype, 0x2a2d0f08, "");
SYMBOL_CRC(dahdi_spantype2str, 0x4c29be43, "");
SYMBOL_CRC(dahdi_lineconfig_bit_name, 0xc597f0d1, "");
SYMBOL_CRC(lineconfig_str, 0xa95ae136, "");
SYMBOL_CRC(dahdi_lboname, 0xb909ae06, "");
SYMBOL_CRC(dahdi_set_dynamic_ops, 0x62a0511c, "");
SYMBOL_CRC(dahdi_create_device, 0x3343baab, "");
SYMBOL_CRC(dahdi_free_device, 0x94571e3b, "");
SYMBOL_CRC(dahdi_init_span, 0xa5f12cec, "");
SYMBOL_CRC(dahdi_get_auto_assign_spans, 0x65d8edc0, "");
SYMBOL_CRC(dahdi_register_device, 0x20ac5ea8, "");
SYMBOL_CRC(dahdi_unregister_device, 0xe55c96c8, "");
SYMBOL_CRC(__dahdi_ec_chunk, 0x2b8e4d1b, "");
SYMBOL_CRC(_dahdi_ec_span, 0x96cfd392, "");
SYMBOL_CRC(_dahdi_transmit, 0x736c1b75, "");
SYMBOL_CRC(_dahdi_receive, 0x7fda9f1b, "");
SYMBOL_CRC(dahdi_register_chardev, 0x597475a3, "");
SYMBOL_CRC(dahdi_unregister_chardev, 0x05d662e5, "");

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x9c6febfc, "add_uevent_var" },
	{ 0xe914e41e, "strcpy" },
	{ 0xf706b8ea, "try_module_get" },
	{ 0xe3ec2f2b, "alloc_chrdev_region" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0xf758c439, "dev_set_name" },
	{ 0xb0e602eb, "memmove" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x16161c04, "device_unregister" },
	{ 0x92540fbf, "finish_wait" },
	{ 0x7587965d, "class_destroy" },
	{ 0x99e6ed9b, "device_initialize" },
	{ 0x6128b5fc, "__printk_ratelimit" },
	{ 0xd5fd90f1, "prepare_to_wait" },
	{ 0x69acdf38, "memcpy" },
	{ 0x37a0cba, "kfree" },
	{ 0x333585b5, "pcpu_hot" },
	{ 0xb3b01031, "seq_lseek" },
	{ 0x8cb52089, "proc_create_data" },
	{ 0x8c26d495, "prepare_to_wait_event" },
	{ 0xb3087f55, "timer_delete_sync" },
	{ 0xe2964344, "__wake_up" },
	{ 0xc67eb448, "get_device" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x92997ed8, "_printk" },
	{ 0x1000e51, "schedule" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x296695f, "refcount_warn_saturate" },
	{ 0xeecf7b5e, "put_device" },
	{ 0x7682ba4e, "__copy_overflow" },
	{ 0xa916b694, "strnlen" },
	{ 0xb2fd5ceb, "__put_user_4" },
	{ 0x6383b27c, "__x86_indirect_thunk_rdx" },
	{ 0x5df8475c, "_dev_info" },
	{ 0xe740ace7, "module_put" },
	{ 0x9c218bc5, "sysfs_create_link" },
	{ 0x476b165a, "sized_strscpy" },
	{ 0x92256a5c, "cdev_add" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0x17fbf181, "bus_unregister" },
	{ 0x19c2320b, "_dev_err" },
	{ 0xf1eb12d0, "device_add" },
	{ 0xad8f513c, "sysfs_remove_link" },
	{ 0x3cf85989, "mod_timer" },
	{ 0x25153b64, "device_create" },
	{ 0xf1a415bd, "class_create" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0xaafdc258, "strcasecmp" },
	{ 0xfbf2d4c0, "driver_unregister" },
	{ 0x449ad0a7, "memcmp" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0xbcab6ee6, "sscanf" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0x2e2b40d2, "strncat" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x11089ac7, "_ctype" },
	{ 0xc01616f4, "device_register" },
	{ 0x7759d670, "device_del" },
	{ 0xa4e127f6, "proc_mkdir" },
	{ 0x1e1e140e, "ns_to_timespec64" },
	{ 0xfb578fc5, "memset" },
	{ 0x97c3c9cf, "param_ops_charp" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0xfb384d37, "kasprintf" },
	{ 0x6ee523f7, "proc_remove" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x15ba50a6, "jiffies" },
	{ 0xfca332f, "seq_read" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x3f4c8c17, "_dev_notice" },
	{ 0x6091b333, "unregister_chrdev_region" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x78534f62, "init_timer_key" },
	{ 0x7f03b6a9, "crc_ccitt_table" },
	{ 0x66cca4f9, "__x86_indirect_thunk_rcx" },
	{ 0x161d889, "__register_chrdev" },
	{ 0x6729d3df, "__get_user_4" },
	{ 0x7ce75d34, "device_destroy" },
	{ 0x6f20cbb9, "remove_proc_entry" },
	{ 0xb43f9365, "ktime_get" },
	{ 0x3c12dfe, "cancel_work_sync" },
	{ 0x8f4a4328, "seq_printf" },
	{ 0xca25f210, "kobject_uevent" },
	{ 0x1d485f22, "single_release" },
	{ 0x13b05988, "dev_printk" },
	{ 0xad73041f, "autoremove_wake_function" },
	{ 0xde0912ee, "kmalloc_trace" },
	{ 0x754d539c, "strlen" },
	{ 0xad4f5fde, "param_ops_int" },
	{ 0x9465d0d3, "single_open" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0xc680d39f, "driver_register" },
	{ 0xf9a482f9, "msleep" },
	{ 0x9c4f0641, "cdev_init" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0xe2c17b5d, "__SCT__might_resched" },
	{ 0x2eb69d30, "kmalloc_caches" },
	{ 0x568f088a, "cdev_del" },
	{ 0xa24f23d8, "__request_module" },
	{ 0xdec74de1, "bus_register" },
	{ 0x2d3385d3, "system_wq" },
	{ 0x6bc3fbc0, "__unregister_chrdev" },
	{ 0x4f5671f6, "module_layout" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "0D3416C7C45E413ACFC66B0");
MODULE_INFO(rhelversion, "9.6");
