#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

KSYMTAB_FUNC(Oct6100ChipOpen, "", "");
KSYMTAB_FUNC(Oct6100ChipClose, "", "");
KSYMTAB_FUNC(Oct6100ChipCloseDef, "", "");
KSYMTAB_FUNC(Oct6100GetInstanceSize, "", "");
KSYMTAB_FUNC(Oct6100GetInstanceSizeDef, "", "");
KSYMTAB_FUNC(Oct6100ChipOpenDef, "", "");
KSYMTAB_FUNC(Oct6100ChannelModify, "", "");
KSYMTAB_FUNC(Oct6100ToneDetectionEnableDef, "", "");
KSYMTAB_FUNC(Oct6100InterruptServiceRoutine, "", "");
KSYMTAB_FUNC(Oct6100InterruptServiceRoutineDef, "", "");
KSYMTAB_FUNC(Oct6100ApiGetCapacityPins, "", "");
KSYMTAB_FUNC(Oct6100ToneDetectionEnable, "", "");
KSYMTAB_FUNC(Oct6100EventGetToneDef, "", "");
KSYMTAB_FUNC(Oct6100EventGetTone, "", "");
KSYMTAB_FUNC(Oct6100ApiGetCapacityPinsDef, "", "");
KSYMTAB_FUNC(Oct6100ChannelOpen, "", "");
KSYMTAB_FUNC(Oct6100ChannelOpenDef, "", "");
KSYMTAB_FUNC(Oct6100ChannelModifyDef, "", "");

SYMBOL_CRC(Oct6100ChipOpen, 0xef4b16bf, "");
SYMBOL_CRC(Oct6100ChipClose, 0xe59837f0, "");
SYMBOL_CRC(Oct6100ChipCloseDef, 0x6eefa3a6, "");
SYMBOL_CRC(Oct6100GetInstanceSize, 0x7f3521aa, "");
SYMBOL_CRC(Oct6100GetInstanceSizeDef, 0x8bcefb0d, "");
SYMBOL_CRC(Oct6100ChipOpenDef, 0x2d4d420f, "");
SYMBOL_CRC(Oct6100ChannelModify, 0xa498779d, "");
SYMBOL_CRC(Oct6100ToneDetectionEnableDef, 0x6ea97ba9, "");
SYMBOL_CRC(Oct6100InterruptServiceRoutine, 0x33729020, "");
SYMBOL_CRC(Oct6100InterruptServiceRoutineDef, 0x3fde93a5, "");
SYMBOL_CRC(Oct6100ApiGetCapacityPins, 0xc054a762, "");
SYMBOL_CRC(Oct6100ToneDetectionEnable, 0x09404793, "");
SYMBOL_CRC(Oct6100EventGetToneDef, 0x73382716, "");
SYMBOL_CRC(Oct6100EventGetTone, 0x238df932, "");
SYMBOL_CRC(Oct6100ApiGetCapacityPinsDef, 0x2c20e37d, "");
SYMBOL_CRC(Oct6100ChannelOpen, 0xf8a56864, "");
SYMBOL_CRC(Oct6100ChannelOpenDef, 0x20728ec0, "");
SYMBOL_CRC(Oct6100ChannelModifyDef, 0x8887613e, "");

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x69acdf38, "memcpy" },
	{ 0x37a0cba, "kfree" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x19c2320b, "_dev_err" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0x20ac5ea8, "dahdi_register_device" },
	{ 0xfb578fc5, "memset" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0xde0912ee, "kmalloc_trace" },
	{ 0xc4f0da12, "ktime_get_with_offset" },
	{ 0x2eb69d30, "kmalloc_caches" },
	{ 0x4f5671f6, "module_layout" },
};

MODULE_INFO(depends, "dahdi");


MODULE_INFO(srcversion, "915B6FBF4CF5CE41BD13773");
MODULE_INFO(rhelversion, "9.6");
