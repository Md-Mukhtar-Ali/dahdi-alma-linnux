#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x79be733f, "dahdi_qevent_lock" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x4a453f53, "iowrite32" },
	{ 0xa27e3480, "pci_enable_device" },
	{ 0x9ed12e20, "kmalloc_large" },
	{ 0xfb578fc5, "memset" },
	{ 0xb164d90f, "pci_request_regions" },
	{ 0xe5434453, "pci_iomap" },
	{ 0xf18416d1, "dma_alloc_attrs" },
	{ 0x4e373669, "pci_set_master" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0x28afbb08, "cpu_latency_qos_add_request" },
	{ 0x333585b5, "pcpu_hot" },
	{ 0x8ddd8aad, "schedule_timeout" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x6729d3df, "__get_user_4" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0x736c1b75, "_dahdi_transmit" },
	{ 0xad4f5fde, "param_ops_int" },
	{ 0x7f0b8305, "param_ops_uint" },
	{ 0x97c3c9cf, "param_ops_charp" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x92997ed8, "_printk" },
	{ 0x3fa69fab, "__pci_register_driver" },
	{ 0x848d372e, "iowrite8" },
	{ 0xe55c96c8, "dahdi_unregister_device" },
	{ 0x37a0cba, "kfree" },
	{ 0x94571e3b, "dahdi_free_device" },
	{ 0x5dc4dc3b, "pci_iounmap" },
	{ 0xb4eb9cc0, "pci_release_regions" },
	{ 0x22ec5205, "cpu_latency_qos_remove_request" },
	{ 0x41474b91, "dma_free_attrs" },
	{ 0xc1514a3b, "free_irq" },
	{ 0x3343baab, "dahdi_create_device" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xfb384d37, "kasprintf" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0x20ac5ea8, "dahdi_register_device" },
	{ 0x30b70f90, "pci_unregister_driver" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x2b8e4d1b, "__dahdi_ec_chunk" },
	{ 0x7fda9f1b, "_dahdi_receive" },
	{ 0xb19b445, "ioread8" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x96a79160, "dahdi_alarm_channel" },
	{ 0xa5bea5d9, "dahdi_hooksig" },
	{ 0x4f5671f6, "module_layout" },
};

MODULE_INFO(depends, "dahdi");

MODULE_ALIAS("pci:v0000E159d00000001sv0000A159sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv0000E159sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv0000B100sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv0000B1D9sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv0000B118sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv0000B119sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv0000A9FDsd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv0000A8FDsd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv0000A800sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv0000A801sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv0000A908sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv0000A901sd*bc*sc*i*");

MODULE_INFO(srcversion, "3CDD63F094F443D9D4C1270");
MODULE_INFO(rhelversion, "9.6");
