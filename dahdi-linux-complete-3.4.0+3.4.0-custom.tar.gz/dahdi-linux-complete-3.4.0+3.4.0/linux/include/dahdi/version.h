/*
 * version.h 
 * Automatically generated
 */
#define DAHDI_VERSION "3.4.0"

